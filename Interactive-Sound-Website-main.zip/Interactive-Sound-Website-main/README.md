# Interactive-Sound-Website
Developed a dynamic website, which generates sound effects upon clicking alphabetic buttons or receiving keyboard inputs. The website provides an interactive user experience where users can explore various sounds by interacting with the interface.


This site was built using GitHub Pages, you can visit this website here[DRUM_KIT](https://chandanapriya026.github.io/Interactive-Sound-Website/)
